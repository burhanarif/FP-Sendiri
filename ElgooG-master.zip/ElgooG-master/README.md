# ElgooG
our groups homework project
